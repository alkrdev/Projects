These fonts are for use with the "Font" drawing mode.

Currently, the LED Matrix Studio only supports fonts up to 8 pixels high. If you'd like this increased then let me know :)

To create a new font:

Create an animation (any width, max 8 pixels high) where each frame represents one character. It's important that the order of the characters starts at ASCII code 32 (space) and follows the ASCII standard. See asciitable.com for more information.

Save the animation: View -> Save as LED Matrix Studio Font...

Your font will be available the next time you load the application!

