/*:
 # Final Examn
 ## Phonebook
 In this assignment we will play around with the basics of a phonebook. Have fun...
 ### All exercises when possible must output to the console!!
*/
//: - callout(Exercise 1): First job is to clean up the code below by adding comments.
//: * To do that you must get to know the code to be able to understand the code...

struct Citizen {
    var firstname: String
    var lastname: String
    var street: String
    var zipcode: String
    var city: String
    var phone: String
    
    var properties: [String] {
        get {
            return [firstname, lastname, street, zipcode, city, phone]
        }
    }
}
var citizenList: [Citizen] = []


func find (_ find:String) {
    var hit = false
    var hits = [Int]()
    for (index, citizen) in citizenList.enumerated() {
        let search = citizen.properties
        for prop in search {
            if prop == find {
                hits.append(index)
                
                hit = true
            }
        }
    }
    if hit == false{
        print("No Match...")
    } else {
        for hit in hits {
            print("Find:  \(find)   =     index:", hit, " -- ", citizenList[hit])
        }
    }
}





//: - callout(Exercise 2): Add 3 new citizens to the list of citizens...
//: * Use the existing code above to formulate a way to add the new citizens to the list.
//:     - Citizen 1: Ole Olsen he lives on Olsensgade 14, 2100 København
//:     - Citizen 2: Pip Hansen she lives on Solsortevænget 13, 6500 Pipstad
//:     - Citizen 2: Kurt Kurtsen he lives on Kurt stræde 35, 5500 Kutistan

citizenList.append(Citizen(firstname: "Kriss", lastname: "Krinkle", street: "Main street", zipcode: "9999", city: "North Pole", phone: "60 44 83 59"))
citizenList.append(Citizen(firstname: "Easter", lastname: "Bunny", street: "Baskett Street", zipcode: "0000", city: "Egg Town", phone: "22 64 09 42"))
citizenList.append(Citizen(firstname: "Touth", lastname: "Fairy", street: "Sweet Tooth Avenue", zipcode: "1111", city: "Gum Town", phone: "31 13 09 42"))

citizenList.append(Citizen(firstname: "Ole", lastname: "Olsen", street: "Olsengade 14", zipcode: "2100", city: "København", phone: "42 24 09 42"))
citizenList.append(Citizen(firstname: "Pip", lastname: "Hansen", street: "Solsortevænget", zipcode: "6500", city: "Pipstad", phone: "88 88 88 88"))
citizenList.append(Citizen(firstname: "Kurt", lastname: "Hansen", street: "Kurt stræde 35", zipcode: "5500", city: "Kutistan", phone: "30 30 70 40"))



//: - callout(Exercise 3): Add a parameter to the struct Citizen:
//: * The parameter is called "phone" and then asign phonenumbers to all the citizens in the code.
// "phone" added under Properties variable, and inside the Citizen Struct - Then the parameter is filled out on all 6 citizens





//: - callout(Exercise 4): Search and destroy...
//: - use the existing code to find the Citizen who lives in Egg Town
find("Egg Town")





//: - Regretfully I have to inform you that Ole has died Thursday night and therefore needs to be deleted from the list of citizens...
find("Ole")
citizenList.remove(at: 3)
citizenList









//: - callout(Exercise 5): Let´s make an app...
//: * make a new file in Xcode and make a Phonebook with the same functionallity as the code above.
//: * it´s okey to expand on the functions and make it more app friendly...
//: ## Happy codings...




